package test.mybatis.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import test.mybatis.domain.Phone;
import test.mybatis.domain.PhoneMapper;
import test.mybatis.domain.User;
import test.mybatis.domain.UserMapper;

import java.util.List;

@RequiredArgsConstructor
@Service
public class UserService {

    private final UserMapper userMapper;
    private final PhoneMapper phoneMapper;

    public List<User> getAll() {
        List<User> userList = userMapper.getAll();

        //User의 phoneList 채우기
        if (userList != null && userList.size() > 0) {
            for (User user : userList) {
                user.setPhoneList(phoneMapper.getByUserId(user.getDbid()));
            }
        }

        return userList;
    }
}
