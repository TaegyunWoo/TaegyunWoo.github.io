package test.mybatis;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import test.mybatis.domain.User;
import test.mybatis.domain.UserMapper;
import test.mybatis.service.UserService;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/user")
public class UserController {

    private final UserMapper userMapper;

    @PostMapping("/insert")
    public User insertUser(@RequestBody User user) {
        userMapper.insert(user);
        return user;
    }

    @GetMapping("/selectAll")
    public List<User> selectAllUser() {
        return userMapper.getAll();
    }

    @GetMapping("/selectById/{id}")
    public User selectById(@PathVariable Long id) {
        return userMapper.getById(id);
    }

}
