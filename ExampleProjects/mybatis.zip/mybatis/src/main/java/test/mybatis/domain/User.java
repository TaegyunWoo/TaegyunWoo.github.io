package test.mybatis.domain;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 사용자 정보 도메인
 */
@Data
public class User {

    private Long dbid;
    private String email;
    private String name;
    private String password;

    //1대다 관계 설정 (1: User, 다: Phone)
    //테이블에 해당 컬럼은 존재하지 않는다.
    private List<Phone> phoneList;
}
