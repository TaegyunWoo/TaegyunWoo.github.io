package test.mybatis;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import test.mybatis.domain.Phone;
import test.mybatis.domain.PhoneMapper;
import test.mybatis.domain.User;
import test.mybatis.domain.UserMapper;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/phone")
public class PhoneController {
    private final PhoneMapper phoneMapper;

    @PostMapping("/insert")
    public Phone insertPhone(@RequestBody Phone phone) {
        phoneMapper.insert(phone);
        return phone;
    }

    @GetMapping("/selectAll")
    public List<Phone> selectAllPhone() {
        return phoneMapper.getAll();
    }

    @GetMapping("/selectById/{id}")
    public Phone selectById(@PathVariable Long id) {
        return phoneMapper.getById(id);
    }

}
