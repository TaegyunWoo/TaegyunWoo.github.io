package test.mybatis.domain;

import org.apache.ibatis.annotations.*;
import java.util.List;

@Mapper
public interface UserMapper {

    //Create
    @Insert("INSERT INTO user(email, name, password) VALUES (#{user.email}, #{user.name}, #{user.password})")
    @Options(useGeneratedKeys = true, keyProperty = "dbid") //SQL이 생성한 KEY 값을 매핑된 객체의 dbid 필드에도 담아주겠다.
    int insert(@Param("user") User user);

    //Read - 1
    @Select("SELECT * FROM user")
    @Results(id="myResultId", value = {
            @Result(property = "dbid", column = "dbid"),
            @Result(property = "email", column = "email"),
            @Result(property = "name", column = "name"),
            @Result(property = "password", column = "password"),
            @Result(property = "phoneList", column = "dbid", many = @Many(select = "test.mybatis.domain.PhoneMapper.getByUserId"))
    }) //필드명과 컬럼명이 같으면 @Results 는 필요없다.
    List<User> getAll();

    //Read - 2
    //@Results 재활용
    @Select("SELECT * FROM user WHERE dbid=#{id}")
    @ResultMap("myResultId")
    User getById(@Param("id") Long id);
}
