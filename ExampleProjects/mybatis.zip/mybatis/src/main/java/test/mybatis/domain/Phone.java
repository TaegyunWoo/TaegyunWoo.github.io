package test.mybatis.domain;

import lombok.Data;

@Data
public class Phone {
    private Long id;
    private String number;
    private Long dbid;
}
