package test.mybatis.domain;

import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface PhoneMapper {
    //Create
    @Insert("INSERT INTO phone(number, dbid) VALUES (#{phone.number}, #{phone.dbid})")
    @Options(useGeneratedKeys = true, keyProperty = "id") //SQL이 생성한 KEY 값을 매핑된 객체의 dbid 필드에도 담아주겠다.
    int insert(@Param("phone") Phone phone);

    //Read - 1
    @Select("SELECT * FROM phone")
    @Results(id="phoneId", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "number", column = "number"),
            @Result(property = "dbid", column = "dbid")
    }) //필드명과 컬럼명이 같으면 @Results 는 필요없다.
    List<Phone> getAll();

    //Read - 2
    //@Results 재활용
    @Select("SELECT * FROM phone WHERE id=#{id}")
    @ResultMap("phoneId")
    Phone getById(@Param("id") Long id);

    @Select("SELECT * FROM phone WHERE dbid=#{dbid}")
    @ResultMap("phoneId")
    List<Phone> getByUserId(@Param("dbid") Long dbid);
}
