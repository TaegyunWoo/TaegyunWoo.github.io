package prac.myPrac;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import prac.myPrac.domain.User;
import prac.myPrac.domain.UserRepository;

import javax.annotation.PostConstruct;

@Component
public class TestUserInit {
    private final UserRepository userRepository;

    @Autowired
    public TestUserInit(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * userRepository 객체를 주입받고 나서, 호출되는 메서드
     */
    @PostConstruct
    public void init() {
        User user = new User();
        user.setName("HongGilDong");
        user.setId("hong");
        user.setPassword("1234");

        userRepository.addUser(user);

    }
}
