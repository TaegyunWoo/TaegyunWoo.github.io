package prac.myPrac.controller;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * 로그인에서 사용될 객체
 */
@Data
public class LoginUserForm {
    @NotBlank
    private String id;

    @NotBlank
    private String password;

    // private String name; //이름은 필요없음
}
