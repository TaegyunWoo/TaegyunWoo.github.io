package prac.myPrac.domain;

import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
public class UserRepository {
    private static final Map<String, User> users = new HashMap<>();

    public User addUser(User user) {
        users.put(user.getId(), user);
        return user;
    }

    /**
     * 조회 성공: 해당 User 객체 반환
     * 조회 실패: null 반환
     */
    public User findById(String id) {
        if (users.containsKey(id)) {
            return users.get(id);
        }
        return null;
    }
}
