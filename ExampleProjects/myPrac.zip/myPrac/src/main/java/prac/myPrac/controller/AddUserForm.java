package prac.myPrac.controller;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * 회원가입 폼에서 사용될 객체
 */
@Data
public class AddUserForm {

    @NotBlank
    private String id;

    @NotBlank
    private String password;

    @NotBlank
    private String name;
}
