package prac.myPrac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import prac.myPrac.domain.User;
import prac.myPrac.service.LoginService;

@Controller
@RequestMapping("/member")
public class LoginController {

    private final LoginService loginService;

    @Autowired
    public LoginController(LoginService loginService) {
        this.loginService = loginService;
    }

    @GetMapping("/login")
    public String viewUserLoginForm(@ModelAttribute User user) {
        return "login";
    }

    @PostMapping("/login")
    public String login(@Validated @ModelAttribute("user") LoginUserForm form,
                        BindingResult bindingResult) {

        //검증 오류시
        if (bindingResult.hasErrors()) {
            return "login";
        }

        //로그인 실행
        User user = loginService.login(form.getId(), form.getPassword());

        //로그인 실패시, 오브젝트 에러
        if (user == null) {
            bindingResult.reject("wrongUser", "아이디나 비밀번호를 확인하세요.");
            return "login";
        }

        // 로그인 성공시, TODO

        return "redirect:/";


    }
}
