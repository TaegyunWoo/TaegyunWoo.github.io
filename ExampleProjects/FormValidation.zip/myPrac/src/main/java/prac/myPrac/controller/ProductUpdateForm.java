package prac.myPrac.controller;

import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
public class ProductUpdateForm {

    private Long productId;

    @NotBlank
    @Pattern(regexp = "^.*\\.Updated")
    private String productName;

    @Min(0)
    private Integer productPrice;
}
