package prac.myPrac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyPracApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyPracApplication.class, args);
	}

}
