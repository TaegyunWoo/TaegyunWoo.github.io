package prac.myPrac.domain;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class ProductRepository {

    private static final Map<Long, Product> productList = new HashMap<>();

    public Product addProduct(Product product) {
        productList.put(product.getProductId(), product);
        return product;
    }

    public Product findById(Long id) {
        return productList.get(id);
    }

    public Product updateProduct(Long targetId, Product product) {
        Product targetProduct = findById(targetId);
        targetProduct.setProductName(product.getProductName());
        targetProduct.setProductPrice(product.getProductPrice());

        return targetProduct;
    }

}
