package prac.myPrac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import prac.myPrac.domain.Product;
import prac.myPrac.domain.ProductRepository;

@Controller
public class ProductController {

    private final ProductRepository productRepository;

    @Autowired
    public ProductController(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @GetMapping("/product/{productId}")
    public String viewProduct(@PathVariable Long productId, Model model) {
        model.addAttribute(productRepository.findById(productId));
        return "product";
    }

    @GetMapping("/product/add")
    public String viewAddForm(@ModelAttribute Product product) {
        return "addProduct";
    }

    @PostMapping("/product/add")
    public String addProduct(@Validated @ModelAttribute("product") ProductAddForm form,
                             BindingResult bindingResult,
                             RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "addProduct";
        }

        //product 추출
        Product product = new Product();
        product.setProductId(form.getProductId());
        product.setProductName(form.getProductName());
        product.setProductPrice(form.getProductPrice());

        //product 추가
        productRepository.addProduct(product);

        //PRG 패턴
        redirectAttributes.addAttribute("productId", product.getProductId());
        return "redirect:/product/{productId}/update";
    }

    @GetMapping("/product/{productId}/update")
    public String viewUpdateForm(@PathVariable Long productId, Model model) {
        Product product = productRepository.findById(productId);
        model.addAttribute(product);
        return "updateProduct";
    }

    @PostMapping("/product/{productId}/update")
    public String updateProduct(@PathVariable Long productId,
                                @Validated @ModelAttribute("product") ProductUpdateForm form,
                                BindingResult bindingResult,
                                RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            return "updateProduct";
        }

        //product 추출
        Product product = new Product();
        product.setProductId(productId);
        product.setProductName(form.getProductName());
        product.setProductPrice(form.getProductPrice());

        //product 수정
        productRepository.updateProduct(productId, product);

        redirectAttributes.addAttribute("productId", product.getProductId());
        return "redirect:/product/{productId}";
    }
}
