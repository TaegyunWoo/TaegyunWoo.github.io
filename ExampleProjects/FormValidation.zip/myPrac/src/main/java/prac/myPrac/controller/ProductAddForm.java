package prac.myPrac.controller;

import lombok.Data;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class ProductAddForm {
    @NotNull
    private Long productId;

    @NotBlank
    private String productName;
    
    @Min(1000)
    private Integer productPrice;
}
