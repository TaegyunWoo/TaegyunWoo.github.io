package prac.myPrac.domain;

import lombok.Data;
import org.hibernate.validator.constraints.Range;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 상품도메인
 */
@Data
public class Product {
    private Long productId;
    private String productName;
    private Integer productPrice;
}
